package extrafeatures;

import java.io.IOException;
import java.util.List;

public class LoginSystem {

    public static User login(String ID, String password) throws IOException {
        List<User> users = UserManager.loadUsers();

        for (User u : users) {
            // Check if username and password match
            if (u.getID().equals(ID) && u.getPassword().equals(password)) {
                return u; // Return the found user object
            }
        }
        return null; // Login failed
    }
}

